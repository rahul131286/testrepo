# JFrog Container Registry Chart Changelog
All changes to this chart will be documented in this file.

## [0.1.0] - Nov 20, 2019
* Initial release of the JFrog Container Registry helm chart
